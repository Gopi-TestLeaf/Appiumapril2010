package runner;


import org.testng.annotations.BeforeTest;

import io.cucumber.testng.CucumberOptions;
import wrappers.AppSpecificWrapper;

@CucumberOptions(features = "src/test/resoures/features",
				glue = "pages")
public class RunnerClass extends AppSpecificWrapper{
	
	@BeforeTest
	public void setData() {
		testCaseName = "TC001_Login";
		testDescription = "Login in LeafOrg App";
		testNodes = "TC001";
		authors = "Gopinath Jayakumar";
		category = "Smoke";
	}

}
