package wrappers;

public class GenericWrappers extends IosWrappers{

}
